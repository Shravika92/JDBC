package com.capgemini.bank.Service;

import com.capgemini.bank.Beans.Customer;

public interface BankService {

	Customer saveCustomer();
	
	String showBalance(long accnum);

	void depositAmount(long acnum, double money1);

	void withdrawAmount(long acnum1, double money);

	double fundTransfer(long yaccnum, long raccnum, long amt);

}
